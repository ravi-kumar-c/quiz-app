import React from "react";

const App=()=> {  
  return (
    <div>
      <h1>I am app.js</h1>
    </div>
  );
}

export default App;