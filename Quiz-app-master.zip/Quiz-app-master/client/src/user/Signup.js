import React, { useState } from "react";
import Base from "../core/Base";
import { Link } from "react-router-dom";
import { signup } from "../auth/helper";

const Signup = () => {
	const [values, setValues] = useState({
		name: "",
		email: "",
		password: "",
		role: "1",
		error: "",
		success: false,
	});

	let { name, role, email, password, error, success } = values;

	const handleChange = (name) => (event) => {
		setValues({ ...values, error: false, [name]: event.target.value });
		//console.log(event.target.value)
	};

	const onSubmit = (event) => {
		event.preventDefault();
		setValues({ ...values, error: false });
		role = Number(role);
		signup({ name, email, password, role})
			.then((data) => {
				console.log(data);
				if (data.error) {
					setValues({ ...values, error: data.error, success: false });
				} else {
					setValues({
						...values,
						name: "",
						email: "",
						role:"1",
						password: "",
						error: "",
						success: true,
					});
				}
			})
			.catch(e=>(console.log(e)));
	};

	const signUpForm = () => {
		return (
			<div className="row">
				<div className="col-md-6 offset-sm-3 text-left" style={{fontSize:"22px"}}>
					<form>
						<div className="form-group-sm">
							<label className="text-light">Name</label>
							<input
								className="form-control"
								onChange={handleChange("name")}
								type="text"
								value={name}
							/>
						</div>
						<div className="form-group-sm">
							<label className="text-light">Email</label>
							<input
								className="form-control"
								onChange={handleChange("email")}
								type="email"
								value={email}
							/>
						</div>

						<div className="form-group-sm">
							<label className="text-light">Password</label>
							<input
								onChange={handleChange("password")}
								className="form-control"
								type="password"
								value={password}
							/>
						</div>
						<div className="row justify-content-center">
									<div className="col-md-3">
										<input type="radio" name="role" value="1" onChange={handleChange("role")}
										checked={role === "1" }
										/>
										<label  style={{marginLeft:"10px"}} >Teacher</label>
									</div>
									<div className="col-md-3">
										<input type="radio" name="role" value="0" onChange={handleChange("role")}
										 checked={role=== "0"}/>
										<label style={{marginLeft:"10px"}}>Student</label>
									</div>
							
						</div>
						<button onClick={onSubmit} className="btn btn-success btn-block">
							Submit
						</button>
					</form>
				</div>
			</div>
		);
	};

	const successMessage = () => {
		return (
			<div className="row">
				<div className="col-md-6 offset-sm-3 text-left">
					<div
						className="alert alert-success"
						style={{ display: success ? "" : "none" }}>
						New account was created successfully. Please
						<Link to="/signin">Login Here</Link>
					</div>
				</div>
			</div>
		);
	};

	const errorMessage = () => {
		return (
			<div className="row">
				<div className="col-md-6 offset-sm-3 text-left">
					<div
						className="alert alert-danger"
						style={{ display: error ? "" : "none" }}>
						{error}
					</div>
				</div>
			</div>
		);
	};

	return (
		<Base title="Sign up page" description="A page for user to sign up!">
			<div className="container">
			{successMessage()}
			{errorMessage()}
			{signUpForm()}
			</div>
		</Base>
	);
};

export default Signup;
